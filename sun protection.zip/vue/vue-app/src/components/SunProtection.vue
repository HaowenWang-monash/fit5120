<template>
  <div class="recommendations">
    <h2>Sun Protection Recommendations</h2>
    <div class="tips">
      <div class="tip">Apply Sunscreen<br>SPF 30+</div>
      <div class="tip">Wear Protective Clothing<br>Long sleeves, hat</div>
      <div class="tip">Seek Shade<br>Stay in shaded areas</div>
    </div>
  </div>
</template>

<style scoped>
.recommendations {
  text-align: center;
  margin-top: 40px;
}
.tips {
  display: flex;
  justify-content: center;
  gap: 20px;
}
.tip {
  padding: 20px;
  background-color: #f1f1f1;
  border-radius: 8px;
  width: 150px;
}
</style>

  