
module.exports = {
  folders: [
    { name: 'Root', path: '.' }
  ]
};